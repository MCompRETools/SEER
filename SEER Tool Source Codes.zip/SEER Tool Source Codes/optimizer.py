import pandas as pd
from itertools import product
from sentence_transformers import SentenceTransformer, util
import os
from langchain_community.vectorstores import Chroma
from langchain_community.embeddings import HuggingFaceEmbeddings
from langchain.docstore.document import Document
from langchain.agents import tool, AgentExecutor, create_react_agent
from langchain_groq import ChatGroq
from langchain_core.prompts import PromptTemplate
import re
from together import Together
import time

# File paths
file1 = "uploads/RequirementSR.xlsx"
rag_prompt = """\

You are an expert requirements engineer and sustainability analyst.
You will be given:

- A requirement A (Functional Requirement — FR — or Non-Functional Requirement — NFR).

- A Sustainability Requirement B (SR).

Situation: Requirement A as written negatively impacts SR B.

Your goal: Revise requirement A so the negative impact on SR B is removed or substantially reduced, while preserving the original meaning, objective, and acceptance criteria of A.
Use the following format:
1. Parse and classify A (FR or NFR). Identify core intent and success criteria.
2. Parse SR: identify sustainability objectives B.
3. Identify nature of conflict between A and B.
4. Generate 3 candidate revisions:
- Minimal tweak (light modification)
- Moderate change (introduce constraints/optimizations)
- Alternative approach (different design achieving same objective)
5. For each: derive measurable acceptance criteria + risks.
6. Score each candidate on preservation, SR impact reduction, confidence.
7. Select recommended candidate + justify.

Output in following JSON format:

{ "original_requirement": "<text>",
"requirement_type": "FR|NFR",
"sustainability_requirement": "<text>",
"candidates": [
{ "label": "Minimal",
"revised_requirement": "<text>",
"preservation_score": <0-100>,
"estimated_SR_impact_reduction": "<Low|Medium|High or %>",
"confidence": "<Low|Medium|High>",
"acceptance_criteria": ["criterion 1", "criterion 2"],
"residual_risks": ["risk 1"] },
{ "label": "Moderate", ... },
{ "label": "Alternative", ... } ],
"recommended": {
"revised_requirement": "<text>",
"justification": "<brief>"
},
}

"""


client = Together(api_key='...........')
sleep_time= 20
df = pd.read_excel(file1)
   df.columns = df.columns.str.strip()
   df = df.rename(columns={'Requirement 1': 'req1', 'SR': 'sr'})
   df = df.dropna(subset=['req1', 'sr'])

   results = pd.DataFrame(columns=['req1', 'sr', 'optimized'])

    for idx, row in df.iterrows():
        query = "Requirement A-" + row.req1 + "Sustainability Requirement B -" + row.sr
        output = ""

        completion = client.chat.completions.create(
            model="............",
            messages=[
                {"role": "system", "content": "You are a helpful assistant. Based on the given context answer the user query "},
                {"role": "user", "content": f"Here is the {query + prompt}"}
            ]
        )

        results = pd.concat([results, pd.DataFrame([{
            "req1": row.req1,
            "req2": row.sr,
            "optimized": completion.choices[0].message.content
        }])], ignore_index=True)

        results.to_excel("uploads/optimizedreq.xlsx", index=False)
	time.sleep(sleep_time)