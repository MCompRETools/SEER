import pandas as pd
from itertools import product
from sentence_transformers import SentenceTransformer, util
import os
from langchain_community.vectorstores import Chroma
from langchain_community.embeddings import HuggingFaceEmbeddings
from langchain.docstore.document import Document
from langchain.agents import tool, AgentExecutor, create_react_agent
from langchain_groq import ChatGroq
from langchain_core.prompts import PromptTemplate
import re
import time

# File paths
file1 = "uploads/Requirements.xlsx"
file2 = "uploads/SRs.xlsx"
output_file = "uploads/Requirement_Pairs.xlsx"
FR_SR_pairs = []
pairs_df = pd.DataFrame()

# Use HuggingFace embeddings (same as in your pipeline)
embedding_model = "sentence-transformers/all-MiniLM-L6-v2"
embeddings = HuggingFaceEmbeddings(model_name=embedding_model)


def read_data_files():
    # Read Excel files
    df1 = pd.read_excel(file1)
    df2 = pd.read_excel(file2)

    # Create Python lists (drop empty rows)
    FRNFR = df1.iloc[:, 0].dropna().tolist()
    SR = df2.iloc[:, 0].dropna().tolist()

    # Print to verify
    print("FRNFR = [")
    for item in FRNFR:
        print(f'    "{item}",')
    print("]\n")

    print("SR = [")
    for item in SR:
        print(f'    "{item}",')
    print("]")

    for fr, sr in product(FRNFR, SR):
        pair_type = "FR-SR" if fr.strip().startswith("FR") else "NFR-SR"
        FR_SR_pairs.append((fr, sr, pair_type))


def get_related_pairs():
    # Convert pairs to DataFrame
    pairs_df = pd.DataFrame(FR_SR_pairs, columns=["Requirement 1", "Requirement 2", "Pair Type"])
    pairs_df.to_excel(output_file, index=False)

    # === 1. Load Fine-Tuned SBERT Model ===
    model = SentenceTransformer('./fine_tuned_req_model_balanced')

    # === 2. Load Requirement Pairs Dataset ===
    df = pd.read_excel('Requirement_Pairs.xlsx')
    df.columns = df.columns.str.strip()
    df = df.rename(columns={'Requirement 1': 'req1', 'Requirement 2': 'req2', 'Pair Type': 'Type'})
    df = df.dropna(subset=['req1', 'req2', 'Type'])

    # === 3. Predict Related Pairs ===
    threshold = 0.65
    related_pairs = []

    for _, row in df.iterrows():
        emb1 = model.encode(str(row.req1), convert_to_tensor=True)
        emb2 = model.encode(str(row.req2), convert_to_tensor=True)
        sim_score = util.cos_sim(emb1, emb2).item()

        if sim_score > threshold:
            related_pairs.append({
                'Requirement 1': row.req1,
                'Requirement 2': row.req2,
                'Pair Type': row.Type,
                'Similarity Score': round(sim_score, 4)
            })

    # === 4. Save Related Pairs to Excel ===
    related_df = pd.DataFrame(related_pairs)
    related_df.to_excel('Related_Pairs_Predicted.xlsx', index=False)
    print(f"Saved {len(related_df)} related pairs to 'Related_Pairs_Predicted.xlsx'")


def load_catalog_lines(file_path, domain):
    docs = []
    with open(file_path, "r", encoding="utf-8") as f:
        for line in f:
            text = line.strip()
            if not text:
                continue
            parts = text.split(" have ")
            if len(parts) >= 2:
                cats = parts[0].split(" and ")
                if len(cats) == 2:
                    cat1, cat2 = cats[0].strip(), cats[1].strip()
                else:
                    cat1, cat2 = parts[0], ""
                relation = "have " + parts[1]
            else:
                cat1, cat2, relation = text, "", ""

            docs.append(
                Document(
                    page_content=text,
                    metadata={
                        "domain": domain,
                        "cat1": cat1,
                        "cat2": cat2,
                        "relation": relation
                    }
                )
            )
    return docs


def load_catalogs():
    global nfr_vs, sus_vs, dep_vs
    # Load both catalogs
    nfr_docs = load_catalog_lines("NFRCat.txt", domain="NFR")
    print(nfr_docs)
    nfr_vs = Chroma.from_documents(
        documents=nfr_docs,
        embedding=embeddings,
        persist_directory="./chroma_nfr"
    )
    nfr_vs.persist()

    sustainability_docs = load_catalog_lines("SusCat.txt", domain="Sustainability")
    sus_vs = Chroma.from_documents(
        documents=sustainability_docs,
        embedding=embeddings,
        persist_directory="./chroma_sustainability"
    )
    print(sustainability_docs)
    sus_vs.persist()

    file_path = "DepCat.txt"
    with open(file_path, "r", encoding="utf-8") as f:
        lines = [line.strip() for line in f if line.strip()]

    documents = [Document(page_content=line, metadata={"chunk_id": i + 1}) for i, line in enumerate(lines)]
    dep_vs = Chroma.from_documents(
        documents=documents,
        embedding=embeddings,
        persist_directory="./Chroma_dependency"
    )
    dep_vs.persist()
    print("Stored Chunks in Vector Store:\n")


@tool
def semantic_search_NFRConflict(query: str) -> str:
    """
    Performs a semantic search on the NFR conflict taxonomy to find the most relevant requirements
    for a given query. Returns a list of the top 3 most similar requirements.
    """
    retriever = nfr_vs.as_retriever(search_type="similarity", k=3)
    docs = retriever.invoke(query)
    return "\n".join([doc.page_content for doc in docs])


@tool
def semantic_search_SusConflict(query: str) -> str:
    """
    Performs a semantic search on the Sustainability conflict taxonomy to find the most relevant requirements
    for a given query. Returns a list of the top 3 most similar requirements.
    """
    retriever = sus_vs.as_retriever(search_type="similarity", k=3)
    docs = retriever.invoke(query)
    return "\n".join([doc.page_content for doc in docs])


@tool
def semantic_search_ReqDep(query: str) -> str:
    """
    Performs a semantic search on the Dependency taxonomy to find the most relevant requirements
    for a given query. Returns a list of the top 3 most similar requirements.
    """
    retriever = dep_vs.as_retriever(search_type="similarity", k=1)
    docs = retriever.invoke(query)
    return "\n".join([doc.page_content for doc in docs])


llm = ChatGroq(
    model="................",
    groq_api_key="...................."
)

# Agents & prompts definition stays the same...
# (kept as in your original, no major indentation issues except in relation_extract)


def extract_relation_and_reason(text: str) -> str:
    pattern = r"Relation Type:\s*(.*?)\s*Reason:\s*(.*)"
    match = re.search(pattern, text, re.DOTALL | re.IGNORECASE)
    if match:
        relation_type = match.group(1).strip()
        reason = match.group(2).strip()
        return f"Relation Type: {relation_type}\nReason: {reason}"
    return ""


def relation_extract():
    read_data_files()
    load_catalogs()
    df = pd.read_excel('Related_Pairs_Predicted.xlsx')
    df.columns = df.columns.str.strip()
    df = df.rename(columns={'Requirement 1': 'req1', 'Requirement 2': 'req2', 'Pair Type': 'Type'})
    df = df.dropna(subset=['req1', 'req2', 'Type'])

    results = pd.DataFrame(columns=['req1', 'req2', 'Type', 'Output'])

    for idx, row in df.iterrows():
        query = "Requirement 1-" + row.req1 + " Requirement 2-" + row.req2
        output = ""

        print(f"Processing Pair Type: {row.Type}")

        if row.Type in ['FR-SR', 'NFR-SR']:
            agent_executor1.handle_parsing_errors = True
            response = agent_1(query)
            output = extract_relation_and_reason(response)
        elif row.Type == 'SR-SR':
            agent_executor2.handle_parsing_errors = True
            response = agent_2(query)
            output = extract_relation_and_reason(response)

        results = pd.concat([results, pd.DataFrame([{
            "req1": row.req1,
            "req2": row.req2,
            "Type": row.Type,
            "Output": output
        }])], ignore_index=True)

        results.to_excel("uploads/Results.xlsx", index=False)
        print(f"Iteration {idx + 1} saved.")

        if idx == 9:
            break
        time.sleep(30)
