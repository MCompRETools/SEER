from langchain_together.llms import Together
from together import Together
import pandas as pd
import json
import os
from langchain_community.graphs import Neo4jGraph
from langchain_core.prompts import FewShotPromptTemplate, PromptTemplate
from langchain.schema import (SystemMessage,HumanMessage,AIMessage)
from langchain_core.output_parsers import JsonOutputParser
from pydantic.v1 import BaseModel, Field
import re
from neo4j import GraphDatabase
from langchain_community.graphs import Neo4jGraph
from langchain_openai import ChatOpenAI, OpenAIEmbeddings
from langchain.vectorstores import FAISS
from langchain_core.documents import Document
from neo4j_graphrag.retrievers import VectorCypherRetriever
from langchain.chains import RetrievalQA
from langchain.prompts import PromptTemplate
from langchain_neo4j import Neo4jGraph
import fitz
from langchain.embeddings import HuggingFaceEmbeddings
from groq import Groq
from langchain_groq import ChatGroq
from langchain.tools import Tool
import re
from langchain.vectorstores import Chroma
from langchain.schema import Document
import pandas as pd
import networkx as nx
import chromadb
from langchain_community.vectorstores import Chroma
from langchain_community.embeddings.sentence_transformer import SentenceTransformerEmbeddings
from langchain.agents import tool, AgentExecutor, create_react_agent
from langchain_core.prompts import PromptTemplate
from langchain_core.language_models import LLM
import time

PDF_PATH = "uploads/Guidelines.pdf"
TXT_PATH = "uploads/Product.txt"
CSV_PATH = "uploads/Taxonomy_created.csv"

client = Together(api_key='............')
NEO4J_URI = "........"
NEO4J_USER = "......"
NEO4J_PASS = "............."
driver = GraphDatabase.driver(NEO4J_URI, auth=(NEO4J_USER, NEO4J_PASS))
langchain_graph = Neo4jGraph(url=NEO4J_URI, username=NEO4J_USER, password=NEO4J_PASS)
embedding_model = SentenceTransformerEmbeddings(model_name="all-MiniLM-L6-v2")

def extract_text_by_goal(pdf_path):
    doc = fitz.open(pdf_path)
    text = "\n".join([page.get_text() for page in doc])
    goal_blocks = re.split(r"Goal\s+(\d+):\s+", text)[1:]
    goal_data = []
    for i in range(0, len(goal_blocks), 2):
        goal_number = goal_blocks[i].strip()
        content = goal_blocks[i + 1].strip()
        goal_name = content.split('\n')[0].strip()
        targets = re.findall(r"\u2022\s*(\d+\.\d+):\s*(.*?)\n", content)
        indicators = re.findall(r"\u2022\s*(\d+\.\d+\.\d+):\s*(.*?)\n", content)
        #progress_match = re.search(r"Progress\s+(.*?)(?=(Goal\s+\d+:|\Z))", content, re.DOTALL)
        #progress = progress_match.group(1).strip() if progress_match else None
        goal_data.append({
            "goal_number": goal_number,
            "goal_name": goal_name,
            "targets": [{"code": t[0], "description": t[1]} for t in targets],
            "indicators": [{"code": i[0], "description": i[1]} for i in indicators],
            #"progress": progress
        })
    return goal_data
def insert_into_neo4j(goal_data):
    with driver.session() as session:
        for goal in goal_data:
            session.execute_write(create_goal_tx, goal)
def create_goal_tx(tx, goal):
    tx.run("""
        MERGE (g:Goal {goal_number: $goal_number})
        SET g.name = $goal_name
    """, goal_number=goal["goal_number"], goal_name=goal["goal_name"])
    for target in goal["targets"]:
        tx.run("""
            MERGE (t:Target {code: $code})
            SET t.description = $description
            WITH t
            MATCH (g:Goal {goal_number: $goal_number})
            MERGE (g)-[:HAS_TARGET]->(t)
        """, code=target["code"], description=target["description"], goal_number=goal["goal_number"])

    for indicator in goal["indicators"]:
    	tx.run("""
        	MERGE (i:Indicator {code: $code})
        	SET i.description = $description
        	WITH i
        	MATCH (t:Target)
        	WHERE $code STARTS WITH t.code
        	MERGE (t)-[:HAS_INDICATOR]->(i)
    	""", code=indicator["code"], description=indicator["description"])

def build_vectorstore_from_graph(graph):
    results = graph.query("""
        MATCH (n)
        WHERE n.description IS NOT NULL
        RETURN id(n) AS id, n.name AS name, n.description AS text
    """)
    documents = [Document(page_content=row["text"], metadata={"id": row["id"], "name": row["name"]}) for row in results]
    embeddings = HuggingFaceEmbeddings(model_name="sentence-transformers/all-MiniLM-L6-v2")
    return FAISS.from_documents(documents, embeddings), embeddings
def build_graphrag_chain(graph, vectorstore, embeddings):
    retriever=vectorstore.as_retriever(search_type="mmr", k=5)
    prompt = PromptTemplate.from_template("""
        Answer the user's question using the provided context. Only use facts from the context.

        Context:
        {context}

        Question:
        {question}

        Answer:
    """)
    llm = ChatGroq(
    model=".............",
    groq_api_key=".............."
)

    return RetrievalQA.from_chain_type(llm=llm, retriever=retriever, chain_type="stuff")
def clear_neo4j_graph():
    with driver.session() as session:
        session.execute_write(lambda tx: tx.run("MATCH (n) DETACH DELETE n"))
def graph_tool():
    print("[INFO] Preparing SDG GraphRAG Tool...")

    def invoke(question: str) -> str:
        data = extract_text_by_goal(PDF_PATH)
        print(data)
        clear_neo4j_graph()
        insert_into_neo4j(data)
        vectorstore, embeddings = build_vectorstore_from_graph(langchain_graph)
        rag_chain = build_graphrag_chain(langchain_graph, vectorstore, embeddings)
        return rag_chain.run(question)
    return Tool(
        name="sdg_graph_rag",
        func=invoke,
        description="Retrieve related sustaianbility goals and targets that may be relevant based on a given product context."
    )
def chunk_by_bracketed_sections(file_path):
    with open(file_path, 'r', encoding='utf-8') as f:
        content = f.read()

    # Find all section headers like [Introduction], [Overall Description], etc.
    pattern = re.compile(r'\[(.+?)\]\s*')
    matches = list(pattern.finditer(content))

    chunks = {}
    for i, match in enumerate(matches):
        section_title = match.group(1).strip()
        start = match.end()
        end = matches[i + 1].start() if i + 1 < len(matches) else len(content)
        section_text = content[start:end].strip()
        chunks[section_title] = section_text

    return chunks

def create_chunk_embed():
    chunks = chunk_by_bracketed_sections(TXT_PATH)
    documents = [Document(page_content=text, metadata={"section": title}) for title, text in chunks.items()]
    persist_directory = "./scopechroma_db"
    return Chroma.from_documents(documents, embedding_model, persist_directory=persist_directory)

# 1a. Create contextual descriptions for better semantic search
def create_contextual_string(row):
    return (
        f"Requirement ID {row['Requirement ID']}: Under the '{row['Dimension']}' dimension and "
        f"the '{row['Issue']}' issue, the requirement is to '{row['Requirement']}'."
    )

# --- PART 2: DEFINING THE AGENT'S TOOLS ---
# These are the functions the agent can choose to call.
# The docstrings are VERY important, as they tell the agent what each tool does.

# Global variables for taxonomy data
vectorstore = None
G = nx.DiGraph() # Initialize G here

def process_taxonomy():
  print("--- Initializing Knowledge Bases ---")
  global vectorstore, G
  taxonomy_df = pd.read_csv("uploads/Taxonomy_created.csv")
  taxonomy_df['contextual_string'] = taxonomy_df.apply(create_contextual_string, axis=1)
  embedding_function = SentenceTransformerEmbeddings(model_name="all-MiniLM-L6-v2")
  vectorstore = Chroma.from_texts(
    texts=taxonomy_df['contextual_string'].tolist(),
    embedding=embedding_function,
    metadatas=[{"id": row['Requirement ID']} for _, row in taxonomy_df.iterrows()]
  )

  G = nx.DiGraph() # Re-initialize G within the function to populate it
  for _, row in taxonomy_df.iterrows():
    G.add_node(row['Dimension'], type='dimension')
    G.add_node(row['Issue'], type='issue')
    G.add_node(row['Requirement ID'], type='requirement', label=row['Requirement'])
    G.add_edge(row['Dimension'], row['Issue'])
    G.add_edge(row['Issue'], row['Requirement ID'])
  return vectorstore, G

@tool
def semantic_search_requirements(query: str) -> str:
    """
    Performs a semantic search on the sustainability taxonomy to find the most relevant requirements for a given query.
    Returns a list of the top 3 most similar requirements.
    """
    retriever = vectorstore.as_retriever(search_type="mmr", k=5)
    docs = retriever.invoke(query)
    return "\n".join([doc.page_content for doc in docs])

@tool
def explore_requirement_context(requirement_id: str) -> str:
    """
    Explores the context of a specific requirement ID in the taxonomy graph.
    It returns its parent issue and other 'sibling' requirements under the same issue.
    """
    if requirement_id not in G:
        return f"Error: Requirement ID '{requirement_id}' not found in the graph."

    # Find parent issue
    parents = list(G.predecessors(requirement_id))
    if not parents:
        return f"No parent issue found for {requirement_id}."
    parent_issue = parents[0]

    # Find sibling requirements
    siblings = [
        f"{node} ({G.nodes[node]['label']})"
        for node in G.successors(parent_issue)
        if node != requirement_id
    ]

    return (
        f"Context for {requirement_id}:\n"
        f"- Parent Issue: {parent_issue}\n"
        f"- Sibling Requirements: {', '.join(siblings) if siblings else 'None'}"
    )
def get_sdg_answer(query: str) -> str:
    tool = graph_tool()
    return tool.run(query)

def run_sustainability_module():
  create_chunk_embed()
  taxonomy_db = process_taxonomy()
  product_scope_db = Chroma(persist_directory="scopechroma_db", embedding_function=embedding_model)

  tools = [
        semantic_search_requirements,
        explore_requirement_context,
    ]
  all_product_chunks = product_scope_db.similarity_search("", k=5)

  llm = ChatGroq(
  model="............",
  groq_api_key="............"
  )

  prompt = PromptTemplate.from_template("""
    Answer the following questions as best you can. You have access to the following tools:

    {tools}

    Use the following format:

    Question: the input question you must answer
    Thought: you should always think about what to do
    Action: the action to take, should be one of [{tool_names}]
    Action Input: the input to the action
    Observation: the result of the action
    ... (this Thought/Action/Action Input/Observation can repeat N times)
    Thought: I now know the final answer
    Final Answer: the final answer to the original input question

    Begin!

    Question: {input}
    Thought:{agent_scratchpad}

	The final output should be in following format
Output:
SR ID: .... Description:.....
    """)

  agent = create_react_agent(
      llm=llm,
      tools=tools,
      prompt=prompt,
  )

  agent_executor = AgentExecutor(agent=agent, tools=tools, verbose=True, )
  results = []
  output_file="uploads/agent_results.txt"
  for chunk in all_product_chunks:
    text="Goals and targets that relates to given product description of a Digital Home as- "+chunk.page_content
    #print(text)
    response= get_sdg_answer(text)
    print("Extracted Context from Knowledge Base...")
    print(response)
    print("\n--- Starting Agent Execution ---")
    result = agent_executor.invoke({
    "input": "Based on the product description chunk "+chunk.page_content+" and SDGs related "+ response +"extract the sustainability requirements for the product. Also use your own reasoning and knowledge to derive related sustaianbaility requirements.",
    "agent_scratchpad": ""
   })

    print("\n--- Agent Finished ---")
    print("\nFinal Report from Agent:")
    print(result['output'])
    results.append(result['output'])
    with open(output_file, "a", encoding="utf-8") as f:
      f.write(result['output'])
    # Return joined results instead of printing
  
    time.sleep(20)
  return "\n\n".join(results)

